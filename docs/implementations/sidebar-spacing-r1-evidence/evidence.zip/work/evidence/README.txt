Base: 2ca2606c4ea04851cf8fe598c3e28864b8d2697a
Chromium: 151.0.7922.173, Linux headless, real production HTML/CSS/JS.
Every browser network request was fulfilled locally; no real provider or database writes.
Extract this archive in the repository root to reproduce the local fixtures.
The before CSS is the exact file from the base commit.
Run node work/sidebar-geometry.cjs before and node work/sidebar-geometry.cjs after.
The fixture expects system /usr/bin/chromium and the environment's playwright-core package.
Desktop PNGs clip the sidebar; mobile PNGs clip the bottom 200px containing context and navigation.
Each geometry JSON contains expanded/collapsed/re-expanded snapshots for each theme and width.
The two expanded passes share the same screenshot filename after verifying the same interactions.
Runtime Boot Safety setup: npm install --ignore-scripts --no-package-lock --cache /workspace/.npm-cache.
System Chromium was used instead of downloading Chromium. All workflow validation commands are run by work/runtime-boot.py.
