const fs=require('fs'),path=require('path'),assert=require('assert/strict');
const {chromium}=require('/opt/codex/runtimes/cua/lib/node_modules/playwright-core');
const root=path.resolve(__dirname,'..'),phase=process.argv[2]||'before';
const out=path.join(__dirname,'evidence');fs.mkdirSync(out,{recursive:true});
const W='11111111-1111-4111-8111-111111111111',B='22222222-2222-4222-8222-222222222222';
(async()=>{const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});try{
const page=await browser.newPage();const errors=[];page.on('pageerror',e=>errors.push(e.message));
await page.route('**/*',route=>{const u=new URL(route.request().url());assert.equal(u.hostname,'localhost');if(u.pathname.startsWith('/api/'))return route.fulfill({json:u.pathname==='/api/auth/session'?{user:null}:u.pathname==='/api/brands'?{brands:[]}:{}});const file=phase==='before'&&u.pathname==='/workspace-sidebar.css'?path.join(__dirname,'before-sidebar.css'):path.resolve(root,u.pathname==='/'?'index.html':'.'+u.pathname);return route.fulfill(fs.existsSync(file)&&fs.statSync(file).isFile()?{path:file}:{body:''});});
await page.goto('http://localhost/');await page.waitForFunction(()=>typeof state!=='undefined'&&!!workspaceSidebarController);
await page.evaluate(({W,B})=>{state.user={email:'fixture@example.com'};state.workspaceCatalog.value={workspaces:[{id:W,name:'Workspace',role:'owner',revision:1,brands:[{id:B,workspace_id:W,name:'Brand',role:'owner',revision:1}],boards:[]}]};state.workspaceCatalog.status='ready';state.workspaceCatalog.activeWorkspaceId=W;state.session.brandId=B;state.currentBoardId=null;renderWorkspaceSidebar();},{W,B});
const results=[];
for(const theme of ['light','dark'])for(const width of [1440,1024,768,375,320])for(const collapsed of [false,true,false]){
await page.setViewportSize({width,height:900});await page.evaluate(({theme,collapsed})=>{document.documentElement.dataset.theme=theme;setSidebarCollapsed(collapsed);},{theme,collapsed});await page.mouse.move(width-1,0);await page.waitForTimeout(300);await page.evaluate(()=>document.getAnimations().forEach(a=>a.finish()));
const geometry=await page.evaluate(()=>{const sels=['#left-sidebar','#workspace-context','.workspace-context-group:first-child','.workspace-context-group:nth-child(2)','#workspace-context-trigger','#workspace-brand-trigger','#workspace-context-avatar','#workspace-brand-avatar','#workspace-context-manage','#workspace-brand-manage','.sidebar-header','.sidebar nav'];return Object.fromEntries(sels.map(s=>{const e=document.querySelector(s),r=e.getBoundingClientRect(),c=getComputedStyle(e);return[s,{x:r.x,y:r.y,width:r.width,height:r.height,display:c.display,visibility:c.visibility,gap:c.gap,margin:c.margin,padding:c.padding,gridRows:c.gridTemplateRows,gridColumns:c.gridTemplateColumns}]}));});
const mode=collapsed?'collapsed':'expanded',record={theme,width,mode,geometry};results.push(record);
await page.screenshot({clip:width>=768?{x:0,y:0,width:Math.ceil(geometry['#left-sidebar'].width),height:900}:{x:0,y:700,width,height:200},path:`${out}/${phase}-${theme}-${width}-${mode}.png`});
if(!collapsed){for(const [button,menu] of [['#workspace-context-manage','#workspace-context-menu'],['#workspace-brand-manage','#brand-context-menu']]){await page.locator(button).click();await page.locator(menu).waitFor({state:'visible'});await page.keyboard.press('Escape');assert.equal(await page.evaluate(()=>document.activeElement.id),button.slice(1));}}
if(phase==='after'&&collapsed){for(const s of ['#workspace-context-manage','#workspace-brand-manage'])assert.equal(geometry[s].height,0);{assert.equal(geometry['#workspace-context-trigger'].height,44);assert.equal(geometry['#workspace-brand-trigger'].y-geometry['#workspace-context-trigger'].y,54);}}
}
if(phase==='after'){
await page.evaluate(()=>{state.workspaceCatalog.value.workspaces[0].role='viewer';state.workspaceCatalog.value.workspaces[0].brands[0].role='viewer';renderWorkspaceSidebar();});
for(const width of [1440,375]){await page.setViewportSize({width,height:900});await page.evaluate(()=>setSidebarCollapsed(true));await page.waitForTimeout(300);await page.evaluate(()=>document.getAnimations().forEach(a=>a.finish()));const boxes=await page.locator('#workspace-context-trigger, #workspace-brand-trigger').evaluateAll(es=>es.map(e=>({y:e.getBoundingClientRect().y,height:e.getBoundingClientRect().height})));assert.equal(boxes[1].y-boxes[0].y,54);assert.equal(boxes[1].height,44);}
for(let i=0;i<20;i++){await page.keyboard.press('Tab');assert(!['workspace-context-manage','workspace-brand-manage'].includes(await page.evaluate(()=>document.activeElement.id)));}
console.log('Read-only roles retain both icons; hidden actions skipped by keyboard');
await page.evaluate(()=>{state.workspaceCatalog.value={workspaces:[]};state.workspaceCatalog.activeWorkspaceId=null;state.session.brandId=null;renderWorkspaceSidebar();});
assert(await page.locator('.workspace-create-action').isVisible());
for(const box of await page.locator('.workspace-context-group').evaluateAll(es=>es.map(e=>e.getBoundingClientRect().height)))assert.equal(box,0);
console.log('Empty-workspace mobile creation layout preserved');
}
assert.deepEqual(errors,[]);fs.writeFileSync(`${out}/${phase}-geometry.json`,JSON.stringify(results,null,2));console.log(`${phase}: ${results.length} theme/viewport/mode captures; menus and focus restoration passed; zero page errors`);
}finally{await browser.close();}})().catch(e=>{console.error(e);process.exit(1);});
