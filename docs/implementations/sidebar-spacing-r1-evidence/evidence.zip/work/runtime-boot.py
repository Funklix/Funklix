import yaml, subprocess, os, json, time
steps=yaml.safe_load(open('.github/workflows/runtime-boot-safety.yml'))['jobs']['runtime-boot-safety']['steps']
results=[]
env={**os.environ,'CHROMIUM_PATH':'/usr/bin/chromium'}
with open('work/evidence/runtime-boot.log','w') as log:
 for step in steps:
  if 'run' not in step or step['name']=='Install focused browser fixture': continue
  for cmd in step['run'].strip().splitlines():
   start=time.time();p=subprocess.run(cmd,shell=True,env=env,stdout=log,stderr=subprocess.STDOUT)
   results.append({'step':step['name'],'command':cmd,'exit':p.returncode,'seconds':round(time.time()-start,2)})
   print(f"{len(results)} {'PASS' if p.returncode==0 else 'FAIL'} {cmd}",flush=True)
json.dump(results,open('work/evidence/runtime-boot.json','w'),indent=2)
assert all(r['exit']==0 for r in results)
